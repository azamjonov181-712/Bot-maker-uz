const Database = require('better-sqlite3');
const path = require('path');
const db = new Database(path.join(__dirname, 'botmarket.db'));

db.exec(`
  PRAGMA journal_mode=WAL;

  CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    email      TEXT NOT NULL UNIQUE,
    password   TEXT NOT NULL,
    nik        TEXT NOT NULL UNIQUE,
    balance    INTEGER NOT NULL DEFAULT 0,
    is_admin   INTEGER NOT NULL DEFAULT 0,
    is_banned  INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS bots (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    icon        TEXT NOT NULL DEFAULT '🤖',
    description TEXT DEFAULT '',
    price       INTEGER NOT NULL DEFAULT 10000,
    bot_code    TEXT DEFAULT '',
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS orders (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    bot_id     INTEGER NOT NULL,
    token      TEXT NOT NULL,
    price      INTEGER NOT NULL,
    bot_user   TEXT DEFAULT '',
    bot_link   TEXT DEFAULT '',
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (bot_id)  REFERENCES bots(id)
  );

  CREATE TABLE IF NOT EXISTS topup_requests (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    amount     INTEGER NOT NULL,
    check_img  TEXT DEFAULT '',
    status     TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

// Default botlarni qo'shish
const count = db.prepare('SELECT COUNT(*) as c FROM bots').get().c;
if (count === 0) {
  const ins = db.prepare('INSERT INTO bots (name, icon, description, price) VALUES (?,?,?,?)');
  [
    ['Konstruktor bot',   '🏗️', "Kanallar uchun kontent yaratuvchi bot",      50000],
    ['Maker bot',         '⚙️', "Universal bot quruvchi",                      50000],
    ['PulBot',            '💰', "To'lov va pul o'tkazma boti",                 15000],
    ['Obunachi bot',      '📢', "Majburiy obuna tekshiruvchi",                 15000],
    ['Special Smm bot',   '📣', "SMM uchun maxsus bot",                        25000],
    ['Convertor bot',     '🔄', "Fayl va media formatlarini o'zgartiruvchi",   30000],
    ['Ultra Raqam bot',   '📱', "Virtual raqam va SMS boti",                   25000],
    ['Get ID bot',        '🆔', "Telegram IDlarini oluvchi bot",               10000],
    ['New Gram bot',      '✨', "Universal Telegram boti",                      20000],
    ['Video Down bot',    '⬇️', "Video yuklovchi bot",                         15000],
    ['Turfa bot',         '🎲', "Ko'p maqsadli fun bot",                       10000],
    ['Special Smm lite',  '📊', "SMM lite versiyasi",                          15000],
    ['Sarmoya bot',       '📈', "Investitsiya monitoring boti",                25000],
    ['Reklamachi bot',    '📰', "Reklama tarqatuvchi bot",                     20000],
    ['Pul bot lite',      '💵', "PulBot lite versiyasi",                       10000],
    ['Obunachi bot Pro',  '⭐', "Obunachi Pro versiyasi",                       35000],
    ['Obunachi bot lite', '🔔', "Obunachi lite versiyasi",                     10000],
    ['Namoz vaqti bot',   '🕌', "Namoz vaqtlari boti",                        10000],
    ['Gram API bot',      '🔌', "Telegram API boti",                           25000],
    ['Avto Nakrutka bot', '🚀', "Avtomatik nakrutka boti",                     50000],
    ['Auto number bot',   '🔢', "Avtomatik raqam boti",                        40000],
  ].forEach(b => ins.run(...b));
  console.log('✅ 21 ta bot qoshildi');
}

module.exports = db;
