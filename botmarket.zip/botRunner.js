const TelegramBot = require('node-telegram-bot-api');

// Xotirada saqlanadigan botlar: token -> instance
const running = new Map();

// ─── BOT HANDLERLARI ─────────────────────────────

function setupGetId(bot) {
  bot.onText(/\/start/, msg => {
    bot.sendMessage(msg.chat.id,
      `👋 *Get ID Bot*ga xush kelibsiz!\n\n` +
      `📋 Buyruqlar:\n/myid — Sizning ID\n/chatid — Chat ID\n/info — To'liq ma'lumot`,
      { parse_mode: 'Markdown' });
  });
  bot.onText(/\/myid/, msg => {
    bot.sendMessage(msg.chat.id,
      `🆔 *Sizning ID:* \`${msg.from.id}\`\n👤 *Ism:* ${msg.from.first_name || ''}\n📛 *Username:* @${msg.from.username || "yo'q"}`,
      { parse_mode: 'Markdown' });
  });
  bot.onText(/\/chatid/, msg => {
    bot.sendMessage(msg.chat.id,
      `💬 *Chat ID:* \`${msg.chat.id}\`\n📝 *Tur:* ${msg.chat.type}`,
      { parse_mode: 'Markdown' });
  });
  bot.onText(/\/info/, msg => {
    bot.sendMessage(msg.chat.id,
      `📊 *Ma'lumot:*\n👤 ID: \`${msg.from.id}\`\n💬 Chat: \`${msg.chat.id}\`\n📝 Tur: ${msg.chat.type}`,
      { parse_mode: 'Markdown' });
  });
  bot.on('message', msg => {
    if (msg.forward_from)
      bot.sendMessage(msg.chat.id,
        `📨 *Forward qilingan:*\n🆔 \`${msg.forward_from.id}\`\n👤 ${msg.forward_from.first_name || ''}`,
        { parse_mode: 'Markdown' });
  });
}

function setupObunachi(bot) {
  bot.onText(/\/start/, msg => {
    bot.sendMessage(msg.chat.id,
      `👋 Salom, *${msg.from.first_name}*!\n\n🔔 Obuna tekshiruv boti.`,
      { parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: [[{ text: '✅ Obunani tekshirish', callback_data: 'check' }]] }
      });
  });
  bot.on('callback_query', q => {
    bot.answerCallbackQuery(q.id, { text: '✅ Tekshirilmoqda...' });
    if (q.data === 'check')
      bot.sendMessage(q.message.chat.id, '✅ *Obuna tasdiqlandi!*', { parse_mode: 'Markdown' });
  });
}

function setupPulBot(bot) {
  bot.onText(/\/start/, msg => {
    bot.sendMessage(msg.chat.id, `💰 *PulBot*ga xush kelibsiz!`, {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: [
        [{ text: '💰 Balansim', callback_data: 'bal' }],
        [{ text: "💳 To'ldirish", callback_data: 'topup' }],
      ]}
    });
  });
  bot.on('callback_query', q => {
    bot.answerCallbackQuery(q.id);
    if (q.data === 'bal') bot.sendMessage(q.message.chat.id, '💰 *Balans:* 0 so\'m', { parse_mode: 'Markdown' });
    if (q.data === 'topup') bot.sendMessage(q.message.chat.id, "💳 Admin: @azamjonov_m");
  });
}

function setupNamoz(bot) {
  const vaqt = {
    toshkent:  { bomdod:'05:12', peshin:'12:30', asr:'16:15', shom:'18:45', xufton:'20:15' },
    samarqand: { bomdod:'05:08', peshin:'12:28', asr:'16:12', shom:'18:42', xufton:'20:12' },
    andijon:   { bomdod:'05:05', peshin:'12:25', asr:'16:10', shom:'18:38', xufton:'20:08' },
    namangan:  { bomdod:'05:04', peshin:'12:24', asr:'16:09', shom:'18:37', xufton:'20:07' },
  };
  bot.onText(/\/start/, msg => {
    bot.sendMessage(msg.chat.id, '🕌 *Namoz Vaqti Bot*\n\nShaharni yozing:', {
      parse_mode: 'Markdown',
      reply_markup: { keyboard: [['Toshkent','Samarqand'],['Andijon','Namangan']], resize_keyboard: true }
    });
  });
  bot.on('message', msg => {
    if (!msg.text) return;
    const sh = msg.text.toLowerCase();
    const v = vaqt[sh];
    if (!v) return;
    bot.sendMessage(msg.chat.id,
      `🕌 *${msg.text} namoz vaqtlari:*\n\n🌅 Bomdod: *${v.bomdod}*\n🌞 Peshin: *${v.peshin}*\n🌇 Asr: *${v.asr}*\n🌆 Shom: *${v.shom}*\n🌙 Xufton: *${v.xufton}*`,
      { parse_mode: 'Markdown' });
  });
}

function setupSmm(bot) {
  bot.onText(/\/start/, msg => {
    bot.sendMessage(msg.chat.id, '📣 *Special SMM Bot*\n\nKanalingizni boshqaring!', {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: [
        [{ text: '📊 Statistika', callback_data: 'stats' }],
        [{ text: '📅 Post yuborish', callback_data: 'post' }],
      ]}
    });
  });
  bot.on('callback_query', q => {
    bot.answerCallbackQuery(q.id);
    if (q.data === 'stats') bot.sendMessage(q.message.chat.id, '📊 *Statistika:*\n👥 Obunachilar: 0\n👁 Korishlar: 0', { parse_mode: 'Markdown' });
    if (q.data === 'post') bot.sendMessage(q.message.chat.id, '✍️ Post matnini yozing:');
  });
}

function setupKonstruktor(bot) {
  const states = {};
  bot.onText(/\/start/, msg => {
    bot.sendMessage(msg.chat.id, '🏗️ *Konstruktor Bot*\n\nBot yarating — kod yozmay!', {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: [
        [{ text: '🏗️ Bot yaratish', callback_data: 'create' }],
        [{ text: '❓ Yordam', callback_data: 'help' }],
      ]}
    });
  });
  bot.on('callback_query', q => {
    bot.answerCallbackQuery(q.id);
    if (q.data === 'create') { states[q.from.id] = 'name'; bot.sendMessage(q.message.chat.id, '📝 Bot nomini kiriting:'); }
    if (q.data === 'help') bot.sendMessage(q.message.chat.id, '❓ *Yordam:*\n1. Bot yaratishni tanlang\n2. Nom kiriting\n3. Tayyor!', { parse_mode: 'Markdown' });
  });
  bot.on('message', msg => {
    if (states[msg.from.id] === 'name' && msg.text && !msg.text.startsWith('/')) {
      states[msg.from.id] = null;
      bot.sendMessage(msg.chat.id, `✅ *"${msg.text}"* yaratildi!\n\nToken olish uchun @BotFather ga boring.`, { parse_mode: 'Markdown' });
    }
  });
}

function setupVideoDown(bot) {
  bot.onText(/\/start/, msg => {
    bot.sendMessage(msg.chat.id, '🎬 *Video Down Bot*\n\nHavola yuboring:', { parse_mode: 'Markdown' });
  });
  bot.on('message', msg => {
    if (!msg.text || msg.text.startsWith('/')) return;
    if (msg.text.includes('youtube') || msg.text.includes('youtu.be') ||
        msg.text.includes('instagram') || msg.text.includes('tiktok')) {
      bot.sendMessage(msg.chat.id, '⏳ Yuklanmoqda...');
      setTimeout(() => bot.sendMessage(msg.chat.id, '⚠️ Demo rejim. Premium uchun @azamjonov_m'), 2000);
    }
  });
}

function setupGeneric(bot, name) {
  bot.onText(/\/start/, msg => {
    bot.sendMessage(msg.chat.id, `👋 *${name}*ga xush kelibsiz!\n\n/help — Yordam`, { parse_mode: 'Markdown' });
  });
  bot.onText(/\/help/, msg => {
    bot.sendMessage(msg.chat.id, `❓ *${name}*\n\n/start — Boshlash\n/help — Yordam`, { parse_mode: 'Markdown' });
  });
}

// ─── BOTNI ISHGA TUSHIRISH ────────────────────────

function startBot(token, botTypeId, botName) {
  if (running.has(token)) return { ok: true, already: true };

  try {
    const bot = new TelegramBot(token, { polling: true });

    switch (Number(botTypeId)) {
      case 8:  case 17: setupGetId(bot); break;
      case 4:  case 16: case 17: setupObunachi(bot); break;
      case 3:  case 15: setupPulBot(bot); break;
      case 18: setupNamoz(bot); break;
      case 5:  case 12: setupSmm(bot); break;
      case 1:  case 2:  setupKonstruktor(bot); break;
      case 10: setupVideoDown(bot); break;
      default: setupGeneric(bot, botName); break;
    }

    bot.on('polling_error', err => {
      console.error(`[${botName}] polling xato:`, err.message);
      if (err.code === 'ETELEGRAM' && err.message.includes('401')) {
        stopBot(token);
      }
    });

    running.set(token, { bot, botTypeId, botName });
    console.log(`✅ Bot ishga tushdi: ${botName} (${token.slice(0,10)}...)`);
    return { ok: true };
  } catch (e) {
    console.error(`Bot ishga tushmadi:`, e.message);
    return { ok: false, error: e.message };
  }
}

function stopBot(token) {
  const entry = running.get(token);
  if (entry) {
    try { entry.bot.stopPolling(); } catch(e) {}
    running.delete(token);
    console.log(`⏹ Bot toxtatildi: ${token.slice(0,10)}...`);
  }
}

function getRunningCount() { return running.size; }

function restoreAll(db) {
  const orders = db.prepare(`
    SELECT o.token, o.bot_id, b.name
    FROM orders o JOIN bots b ON b.id = o.bot_id
  `).all();
  let restored = 0;
  orders.forEach(o => {
    const r = startBot(o.token, o.bot_id, o.name);
    if (r.ok && !r.already) restored++;
  });
  console.log(`♻️  ${restored} ta bot qayta ishga tushirildi`);
}

module.exports = { startBot, stopBot, getRunningCount, restoreAll };
