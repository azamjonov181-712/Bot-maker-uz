require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const axios   = require('axios');
const db      = require('./db');
const { startBot, stopBot, getRunningCount, restoreAll } = require('./botRunner');

const app    = express();
const PORT   = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || 'botmarket_secret_2024_change_me';
const ADMIN  = process.env.ADMIN_EMAIL || 'azamjonov181@gmail.com';

// ── MIDDLEWARE ──────────────────────────────────────
app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
app.use('/uploads', express.static(uploadsDir));

const upload = multer({
  storage: multer.diskStorage({
    destination: (_, __, cb) => cb(null, uploadsDir),
    filename:    (_, f, cb)  => cb(null, `chek_${Date.now()}${path.extname(f.originalname)}`)
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, f, cb) => cb(null, /jpeg|jpg|png|webp/.test(f.mimetype))
});

// ── HELPERS ──────────────────────────────────────────
const ok  = (res, data={}, msg='')  => res.json({ ok: true,  msg, ...data });
const err = (res, msg, status=200)  => res.status(status).json({ ok: false, msg });

function auth(req, res, next) {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  if (!t) return err(res, 'Token kerak');
  try {
    const payload = jwt.verify(t, SECRET);
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(payload.id);
    if (!u)         return err(res, 'Foydalanuvchi topilmadi');
    if (u.is_banned) return err(res, 'Hisobingiz bloklangan');
    req.u = u; next();
  } catch { err(res, 'Token muddati tugagan, qayta kiring'); }
}

function admin(req, res, next) {
  auth(req, res, () => {
    if (!req.u.is_admin) return err(res, 'Admin huquqi kerak');
    next();
  });
}

// ── HEALTH ───────────────────────────────────────────
app.get('/', (_, res) => res.json({
  service: 'BotMarket API', status: 'ok',
  bots_running: getRunningCount(), time: new Date().toISOString()
}));

// ── REGISTER ─────────────────────────────────────────
app.post('/api/register', (req, res) => {
  let { email='', password='', nik='' } = req.body;
  email = email.trim().toLowerCase();
  nik   = nik.trim().toLowerCase().replace(/\s+/g, '');
  if (!email || !password || !nik)                return err(res, "Barcha maydonlarni to'ldiring");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return err(res, "Email noto'g'ri");
  if (password.length < 6)                        return err(res, "Parol kamida 6 ta belgi");
  if (!/^[a-z0-9_]{3,20}$/.test(nik))            return err(res, "Nik 3-20 ta harf/raqam/_");

  if (db.prepare('SELECT id FROM users WHERE email=? OR nik=?').get(email, nik))
    return err(res, "Bu email yoki nik band");

  const hash    = bcrypt.hashSync(password, 10);
  const isAdmin = email === ADMIN ? 1 : 0;
  const { lastInsertRowid: id } = db.prepare(
    'INSERT INTO users (email,password,nik,is_admin) VALUES (?,?,?,?)'
  ).run(email, hash, nik, isAdmin);

  const token = jwt.sign({ id }, SECRET, { expiresIn: '30d' });
  ok(res, { token, nik, is_admin: !!isAdmin, balance: 0 }, `Xush kelibsiz, @${nik}!`);
});

// ── LOGIN ─────────────────────────────────────────────
app.post('/api/login', (req, res) => {
  const { email='', password='' } = req.body;
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(email.trim().toLowerCase());
  if (!u || !bcrypt.compareSync(password, u.password)) return err(res, "Email yoki parol noto'g'ri");
  if (u.is_banned) return err(res, "Hisobingiz bloklangan");
  const token = jwt.sign({ id: u.id }, SECRET, { expiresIn: '30d' });
  ok(res, { token, nik: u.nik, email: u.email, balance: u.balance, is_admin: !!u.is_admin },
     `Xush kelibsiz, @${u.nik}!`);
});

// ── ME ────────────────────────────────────────────────
app.get('/api/me', auth, (req, res) => {
  const u = req.u;
  ok(res, { id: u.id, nik: u.nik, email: u.email, balance: u.balance, is_admin: !!u.is_admin });
});

// ── CHANGE PASSWORD ───────────────────────────────────
app.post('/api/change-password', auth, (req, res) => {
  const { new_password='' } = req.body;
  if (new_password.length < 6) return err(res, "Kamida 6 ta belgi");
  db.prepare('UPDATE users SET password=? WHERE id=?').run(bcrypt.hashSync(new_password, 10), req.u.id);
  ok(res, {}, 'Parol yangilandi');
});

// ── BOTS LIST (public) ────────────────────────────────
app.get('/api/bots', (_, res) => {
  const bots = db.prepare(
    'SELECT id,name,icon,description,price FROM bots WHERE is_active=1 ORDER BY id'
  ).all();
  ok(res, { bots });
});

// ── BUY BOT — TOKEN BILAN BOT AVTO ISHGA TUSHADI ─────
app.post('/api/buy', auth, async (req, res) => {
  const { bot_id, token } = req.body;
  if (!bot_id || !token)       return err(res, "Ma'lumotlar to'liq emas");
  if (!String(token).includes(':')) return err(res, "Token formati noto'g'ri");

  const u   = req.u;
  const bot = db.prepare('SELECT * FROM bots WHERE id=? AND is_active=1').get(bot_id);
  if (!bot) return err(res, "Bot topilmadi");

  // Balansni yangilangan holda tekshirish
  const bal = db.prepare('SELECT balance FROM users WHERE id=?').get(u.id).balance;
  if (bal < bot.price)
    return err(res, `Balans yetarli emas. Kerak: ${bot.price.toLocaleString()} so'm, sizda: ${bal.toLocaleString()} so'm`);

  // Tokenni Telegram da tekshirish
  let botUsername = '', botLink = '';
  try {
    const tg = await axios.get(`https://api.telegram.org/bot${token}/getMe`, { timeout: 6000 });
    if (!tg.data.ok) return err(res, "Token noto'g'ri yoki bot topilmadi");
    botUsername = tg.data.result.username || '';
    botLink     = `https://t.me/${botUsername}`;
  } catch (e) {
    if (e.response?.status === 401) return err(res, "Token noto'g'ri!");
    return err(res, "Telegram bilan bog'lanishda xato. Tokenni tekshiring.");
  }

  // Tranzaksiya: pul ayirish + order saqlash
  const orderId = db.transaction(() => {
    db.prepare('UPDATE users SET balance = balance - ? WHERE id=?').run(bot.price, u.id);
    const { lastInsertRowid } = db.prepare(
      'INSERT INTO orders (user_id,bot_id,token,price,bot_user,bot_link) VALUES (?,?,?,?,?,?)'
    ).run(u.id, bot_id, token, bot.price, botUsername, botLink);
    return lastInsertRowid;
  })();

  // Botni ishga tushirish
  const started = startBot(token, bot.id, bot.name);
  const newBal  = db.prepare('SELECT balance FROM users WHERE id=?').get(u.id).balance;

  ok(res, {
    order_id: orderId,
    bot_username: botUsername,
    bot_link: botLink,
    new_balance: newBal,
    running: started.ok
  }, `🎉 ${bot.name} ishga tushdi!`);
});

// ── ORDERS ────────────────────────────────────────────
app.get('/api/orders', auth, (req, res) => {
  const orders = db.prepare(`
    SELECT o.id, o.price, o.token, o.created_at, o.bot_user, o.bot_link,
           b.name as bot_name, b.icon
    FROM orders o JOIN bots b ON b.id=o.bot_id
    WHERE o.user_id=? ORDER BY o.created_at DESC
  `).all(req.u.id);
  ok(res, { orders });
});

// ── TOPUP ─────────────────────────────────────────────
app.post('/api/topup', auth, upload.single('check_img'), (req, res) => {
  const amount = parseInt(req.body.amount);
  if (!amount || amount < 1000) return err(res, "Minimum 1000 so'm");
  const img = req.file ? `/uploads/${req.file.filename}` : '';
  db.prepare('INSERT INTO topup_requests (user_id,amount,check_img) VALUES (?,?,?)').run(req.u.id, amount, img);
  ok(res, {}, "So'rov yuborildi! Admin tasdiqlashini kuting ⏳");
});

// ════════════════════════════════════════════════════════
//  ADMIN ROUTES
// ════════════════════════════════════════════════════════

app.get('/api/admin/stats', admin, (_, res) => {
  ok(res, {
    users:   db.prepare('SELECT COUNT(*) as c FROM users').get().c,
    orders:  db.prepare('SELECT COUNT(*) as c FROM orders').get().c,
    revenue: db.prepare('SELECT COALESCE(SUM(price),0) as s FROM orders').get().s,
    pending: db.prepare("SELECT COUNT(*) as c FROM topup_requests WHERE status='pending'").get().c,
    running: getRunningCount()
  });
});

app.get('/api/admin/requests', admin, (_, res) => {
  const requests = db.prepare(`
    SELECT r.*, u.nik, u.email FROM topup_requests r
    JOIN users u ON u.id=r.user_id WHERE r.status='pending' ORDER BY r.created_at DESC
  `).all();
  ok(res, { requests });
});

app.post('/api/admin/approve', admin, (req, res) => {
  const r = db.prepare("SELECT * FROM topup_requests WHERE id=? AND status='pending'").get(req.body.id);
  if (!r) return err(res, "Topilmadi");
  db.transaction(() => {
    db.prepare("UPDATE topup_requests SET status='approved' WHERE id=?").run(r.id);
    db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(r.amount, r.user_id);
  })();
  ok(res, {}, `+${r.amount.toLocaleString()} so'm qo'shildi`);
});

app.post('/api/admin/reject', admin, (req, res) => {
  db.prepare("UPDATE topup_requests SET status='rejected' WHERE id=?").run(req.body.id);
  ok(res, {}, "Rad etildi");
});

app.get('/api/admin/users', admin, (req, res) => {
  const q = `%${req.query.q || ''}%`;
  ok(res, { users: db.prepare(
    'SELECT id,nik,email,balance,is_admin,is_banned,created_at FROM users WHERE nik LIKE ? OR email LIKE ? ORDER BY id DESC'
  ).all(q, q) });
});

app.post('/api/admin/funds', admin, (req, res) => {
  const { uid, amount, type } = req.body;
  const amt = parseInt(amount);
  if (!uid || !amt) return err(res, "Ma'lumotlar to'liq emas");
  if (type === 'add')
    db.prepare('UPDATE users SET balance=balance+? WHERE id=?').run(amt, uid);
  else
    db.prepare('UPDATE users SET balance=MAX(0,balance-?) WHERE id=?').run(amt, uid);
  const newBal = db.prepare('SELECT balance FROM users WHERE id=?').get(uid).balance;
  ok(res, { new_balance: newBal }, `${type==='add'?'+':'-'}${amt.toLocaleString()} so'm`);
});

app.post('/api/admin/ban', admin, (req, res) => {
  db.prepare('UPDATE users SET is_banned=1-is_banned WHERE id=?').run(req.body.uid);
  const banned = !!db.prepare('SELECT is_banned FROM users WHERE id=?').get(req.body.uid).is_banned;
  ok(res, { banned }, banned ? 'Bloklandi' : 'Ban olib tashlandi');
});

// ── ADMIN BOTS ────────────────────────────────────────
app.get('/api/admin/bots', admin, (_, res) => {
  ok(res, { bots: db.prepare('SELECT * FROM bots ORDER BY id').all() });
});

app.post('/api/admin/bot/add', admin, (req, res) => {
  const { name, price, icon='🤖', description='', bot_code='' } = req.body;
  if (!name || !price) return err(res, 'Nom va narx kerak');
  const { lastInsertRowid: id } = db.prepare(
    'INSERT INTO bots (name,price,icon,description,bot_code) VALUES (?,?,?,?,?)'
  ).run(name, parseInt(price), icon, description, bot_code);
  ok(res, { id }, "Bot qo'shildi ✅");
});

app.post('/api/admin/bot/save', admin, (req, res) => {
  const { id, name, price, icon='🤖', description='', bot_code='' } = req.body;
  if (!id) return err(res, 'Bot IDsi kerak');
  db.prepare('UPDATE bots SET name=?,price=?,icon=?,description=?,bot_code=? WHERE id=?')
    .run(name, parseInt(price), icon, description, bot_code, id);
  ok(res, {}, 'Saqlandi ✅');
});

app.post('/api/admin/bot/toggle', admin, (req, res) => {
  db.prepare('UPDATE bots SET is_active=1-is_active WHERE id=?').run(req.body.id);
  ok(res, {}, "O'zgartirildi");
});

app.post('/api/admin/bot/delete', admin, (req, res) => {
  db.prepare('DELETE FROM bots WHERE id=?').run(req.body.id);
  ok(res, {}, "O'chirildi");
});

// ── START ─────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 BotMarket server: http://localhost:${PORT}`);
  console.log(`👑 Admin: ${ADMIN}`);
  restoreAll(db);
});
